<?php
include 'ip.php';
header('Location: /live.html');
exit
?>
